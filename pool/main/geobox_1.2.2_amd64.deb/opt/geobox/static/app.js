const PROTOCOLS = [
  "vless",
  "hysteria2",
  "wireguard",
  "openvpn",
  "socks5",
  "ikev2",
  "l2tp_ipsec",
  "sstp",
  "zerotier",
];

const DNS_MODES = ["default", "google_doh", "cloudflare_doh", "isp", "custom"];
const WEBRTC_MODES = ["auto", "spoof", "block", "none"];
const WIFI_SECURITY = ["open", "wpa2", "wpa3", "wpa2_wpa3_mixed", "wep"];
const WIFI_BANDS = ["2.4g", "5g"];
const WIFI_MODES = ["b", "g", "n", "ac"];
const TLS_FINGERPRINTS = ["chrome", "firefox", "safari", "edge"];
const SECTIONS = ["overview", "network", "vpns", "wifi", "fingerprints", "system"];
const VPN_PROFILE_UI_KEY = Symbol("vpnProfileUiKey");
const isBrowser = typeof window !== "undefined" && typeof document !== "undefined";
let nextVPNProfileUIKey = 1;

const state = {
  dashboard: null,
  draftConfig: null,
  // UI-only state contract:
  // - selectedVPNProfileID tracks a stable in-memory UI key, not profile.id.
  // - add selects the new profile.
  // - delete falls back to the next profile or clears selection.
  // - rerenders must never recreate or discard draftConfig.
  selectedVPNProfileID: null,
  vpnProfileAdvancedOpen: Object.create(null),
  currentSection: "overview",
  currentScreen: "home",
  dirty: false,
  toast: null,
  planOutput: "No operation run yet.",
};
let handlersAttached = false;

async function fetchJson(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!response.ok) {
    const body = await response.text();
    throw new Error(body || `Request failed: ${response.status}`);
  }
  return response.json();
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function escapeJSString(value) {
  return String(value ?? "")
    .replaceAll("\\", "\\\\")
    .replaceAll("'", "\\'");
}

function displayUnknown(value, fallback = "Unknown") {
  if (value === null || value === undefined) {
    return fallback;
  }
  if (typeof value === "string" && value.trim() === "") {
    return fallback;
  }
  return String(value);
}

// Navigation
function navigateTo(screenId) {
  document.querySelectorAll(".screen").forEach((s) => s.classList.remove("active"));
  const screen = document.getElementById(`screen-${screenId}`);
  if (screen) {
    screen.classList.add("active");
    state.currentScreen = screenId;
  }
}

function navigateBack() {
  navigateTo("home");
}

function setupNavigation() {
  // Back buttons
  document.querySelectorAll("[data-back]").forEach((btn) => {
    btn.addEventListener("click", navigateBack);
  });
}

// SVG Icons
const ICONS = {
  vpn: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>`,
  wifi: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M1 9l2 2c4.97-4.97 13.03-4.97 18 0l2-2C16.93 2.93 7.08 2.93 1 9zm8 8l3 3 3-3c-1.65-1.66-4.34-1.66-6 0zm-4-4l2 2c2.76-2.76 7.24-2.76 10 0l2-2C15.14 9.14 8.87 9.14 5 13z"/></svg>`,
  network: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 6h18V4H4c-1.1 0-2 .9-2 2v11H0v3h14v-3H4V6zm19 2h-6c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h6c.55 0 1-.45 1-1V9c0-.55-.45-1-1-1zm-1 9h-4v-7h4v7z"/></svg>`,
  clients: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>`,
  system: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>`,
  fingerprint: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.81 4.47c-.08 0-.16-.02-.23-.06C15.66 3.42 14 3 12.01 3c-1.98 0-3.86.47-5.57 1.41-.24.13-.54.04-.68-.2-.13-.24-.04-.55.2-.68C7.82 2.52 9.86 2 12.01 2c2.13 0 3.99.47 6.03 1.52.25.13.34.43.21.67-.09.18-.26.28-.44.28zM3.5 9.72c-.1 0-.2-.03-.29-.09-.23-.16-.28-.47-.12-.7.99-1.4 2.25-2.5 3.75-3.27C9.98 4.04 14 4.03 17.15 5.65c1.5.77 2.76 1.86 3.75 3.25.16.22.11.54-.12.7-.23.16-.54.11-.7-.12-.9-1.26-2.04-2.25-3.39-2.94-2.87-1.47-6.54-1.47-9.4.01-1.36.7-2.5 1.7-3.4 2.96-.08.14-.23.21-.39.21zm6.25 12.07c-.13 0-.26-.05-.35-.15-.87-.87-1.34-1.43-2.01-2.64-.69-1.23-1.05-2.73-1.05-4.34 0-2.97 2.54-5.39 5.66-5.39s5.66 2.42 5.66 5.39c0 .28-.22.5-.5.5s-.5-.22-.5-.5c0-2.42-2.09-4.39-4.66-4.39-2.57 0-4.66 1.97-4.66 4.39 0 1.44.32 2.77.93 3.85.64 1.15 1.08 1.64 1.85 2.42.19.2.19.51 0 .71-.11.1-.24.15-.37.15zm7.17-1.85c-1.19 0-2.24-.3-3.1-.89-1.49-1.01-2.38-2.65-2.38-4.39 0-.28.22-.5.5-.5s.5.22.5.5c0 1.41.72 2.74 1.94 3.56.71.48 1.54.71 2.54.71.24 0 .64-.03 1.04-.1.27-.05.53.13.58.41.05.27-.13.53-.41.58-.57.11-1.07.12-1.21.12zM14.91 22c-.04 0-.09-.01-.13-.02-1.59-.44-2.63-1.03-3.72-2.1-1.4-1.39-2.17-3.24-2.17-5.22 0-1.62 1.38-2.94 3.08-2.94 1.7 0 3.08 1.32 3.08 2.94 0 1.07.93 1.94 2.08 1.94s2.08-.87 2.08-1.94c0-3.77-3.25-6.83-7.25-6.83-2.84 0-5.44 1.58-6.61 4.03-.39.81-.59 1.76-.59 2.8 0 .78.07 2.01.67 3.61.1.26-.03.55-.29.64-.26.1-.55-.04-.64-.29-.49-1.31-.73-2.61-.73-3.96 0-1.2.23-2.29.68-3.24 1.33-2.79 4.28-4.6 7.51-4.6 4.55 0 8.25 3.51 8.25 7.83 0 1.62-1.38 2.94-3.08 2.94s-3.08-1.32-3.08-2.94c0-1.07-.93-1.94-2.08-1.94s-2.08.87-2.08 1.94c0 1.71.66 3.31 1.87 4.51.95.94 1.86 1.46 3.27 1.85.27.07.42.35.35.61-.05.23-.26.38-.47.38z"/></svg>`,
  settings: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg>`,
};

// Home Grid
function getTileStatus(type, data) {
  const runtime = data?.runtime || {};
  const config = data?.config || {};

  switch (type) {
    case "vpn": {
      const units = config.vpn_units || [];
      const running = units.filter((u) => runtime.vpn_units?.[u.id]?.running).length;
      const total = units.length;
      if (running === total && total > 0) {
        return { text: `${running} running`, active: true, error: false };
      } else if (running > 0) {
        return { text: `${running}/${total}`, active: true, error: false };
      } else if (total > 0) {
        return { text: `${total} stopped`, active: false, error: true };
      }
      return { text: "0 units", active: false, error: false };
    }
    case "wifi": {
      const networks = config.wifi_networks || [];
      const count = networks.length;
      return { text: count === 1 ? "1 AP" : `${count} APs`, active: count > 0, error: false };
    }
    case "network": {
      const bridges = config.bridges || [];
      return { text: `${bridges.length} bridge${bridges.length !== 1 ? "s" : ""}`, active: bridges.length > 0, error: false };
    }
    case "clients": {
      const clients = runtime.clients || [];
      return { text: `${clients.length} online`, active: clients.length > 0, error: false };
    }
    case "system": {
      const startedAt = runtime.started_at;
      if (!startedAt) return { text: "Unknown", active: false, error: false };
      const uptime = formatUptime(startedAt);
      return { text: uptime, active: true, error: false };
    }
    case "fingerprint": {
      const policies = config.fingerprint_policies || [];
      return { text: `${policies.length} policies`, active: policies.length > 0, error: false };
    }
    default:
      return { text: "", active: false, error: false };
  }
}

function formatUptime(startedAt) {
  const start = new Date(startedAt);
  const now = new Date();
  const diffMs = now - start;
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

  if (days > 0) {
    return `${days}d ${hours}h`;
  }
  return `${hours}h`;
}

function renderHomeGrid(data) {
  const grid = document.getElementById("home-grid");
  if (!grid) return;

  const tiles = [
    { type: "vpn", label: "VPN", icon: "vpn" },
    { type: "wifi", label: "Wi-Fi", icon: "wifi" },
    { type: "network", label: "Network", icon: "network" },
    { type: "clients", label: "Clients", icon: "clients" },
    { type: "system", label: "System", icon: "system" },
    { type: "fingerprint", label: "Fingerprint", icon: "fingerprint" },
  ];

  let html = "";

  tiles.forEach((tile) => {
    const status = getTileStatus(tile.type, data);
    const classes = ["tile"];
    if (status.active) classes.push("active");
    if (status.error) classes.push("error");

    html += `
      <button class="${classes.join(" ")}" data-screen="${tile.type}">
        <div class="tile-icon">${ICONS[tile.icon]}</div>
        <div class="tile-label">${tile.label}</div>
        <div class="tile-status">${escapeHtml(status.text)}</div>
      </button>
    `;
  });

  // Settings row
  html += `
    <button class="tile settings" data-screen="settings">
      <div class="tile-content">
        <div class="tile-icon">${ICONS.settings}</div>
        <div class="tile-label">Settings</div>
      </div>
      <span class="tile-chevron">›</span>
    </button>
  `;

  grid.innerHTML = html;

  // Add click handlers
  grid.querySelectorAll("[data-screen]").forEach((tile) => {
    tile.addEventListener("click", () => {
      const screen = tile.dataset.screen;
      navigateTo(screen);
      renderScreen(screen, data);
    });
  });
}

// VPN Units Screen
function renderVPNScreen(data) {
  const container = document.getElementById("vpn-list");
  if (!container) return;

  const config = data?.config || {};
  const runtime = data?.runtime || {};
  const units = config.vpn_units || [];

  if (units.length === 0) {
    container.innerHTML = `<div class="empty-state">No VPN units configured. Add one in Settings.</div>`;
    return;
  }

  let html = "";
  units.forEach((unit) => {
    const profile = config.vpn_profiles?.find((p) => p.id === unit.profile_id);
    const profileName = profile?.name || "Unknown Profile";
    const unitState = runtime.vpn_units?.[unit.id];
    const running = unitState?.running;
    const statusClass = running ? "running" : "stopped";
    const cardClass = running ? "card active" : "card error";

    html += `
      <div class="${cardClass}" data-unit-id="${escapeHtml(unit.id)}">
        <div class="card-header">
          <div>
            <div class="card-title">${escapeHtml(unit.name || profileName)}</div>
            <div class="card-meta">bridge: ${escapeHtml(unit.bridge_id || "none")}</div>
          </div>
          <div class="card-status ${statusClass}">
            <span class="status-dot ${statusClass}"></span>
            ${running ? "Running" : "Stopped"}
          </div>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

// WiFi Screen
function renderWiFiScreen(data) {
  const container = document.getElementById("wifi-list");
  if (!container) return;

  const config = data?.config || {};
  const runtime = data?.runtime || {};
  const networks = config.wifi_networks || [];

  if (networks.length === 0) {
    container.innerHTML = `<div class="empty-state">No Wi-Fi networks configured.</div>`;
    return;
  }

  let html = "";
  networks.forEach((net) => {
    const wifiState = runtime.wifi_networks?.[net.id];
    const running = wifiState?.running;
    const clientCount = wifiState?.client_count || 0;
    const statusClass = running ? "running" : "stopped";
    const cardClass = running ? "card active" : "card";

    html += `
      <div class="${cardClass}" data-wifi-id="${escapeHtml(net.id)}">
        <div class="card-header">
          <div>
            <div class="card-title">${escapeHtml(net.ssid || net.name)}</div>
            <div class="card-meta">${escapeHtml(net.band || "2.4g")} • ${escapeHtml(net.security || "wpa2")}</div>
          </div>
          <div class="card-status ${statusClass}">
            <span class="status-dot ${statusClass}"></span>
            ${clientCount} client${clientCount !== 1 ? "s" : ""}
          </div>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

// Clients Screen
function renderClientsScreen(data) {
  const container = document.getElementById("clients-list");
  if (!container) return;

  const runtime = data?.runtime || {};
  const clients = runtime.clients || [];

  if (clients.length === 0) {
    container.innerHTML = `<div class="empty-state">No clients connected.</div>`;
    return;
  }

  let html = "";
  clients.forEach((client) => {
    html += `
      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">${escapeHtml(client.hostname || client.ip || "Unknown")}</div>
            <div class="card-meta">${escapeHtml(client.mac || "")} • ${escapeHtml(client.ip || "")}</div>
          </div>
          ${client.signal_dbm ? `<div class="card-status">${client.signal_dbm} dBm</div>` : ""}
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

// Settings Screen
function renderSettingsScreen(data) {
  const container = document.getElementById("settings-list");
  if (!container) return;

  const config = data?.config || {};

  const rows = [
    { label: "VPN Profiles", value: `${config.vpn_profiles?.length || 0}`, action: "vpn-profiles" },
    { label: "VPN Units", value: `${config.vpn_units?.length || 0}`, action: "vpn-units" },
    { label: "Fingerprint Profiles", value: `${config.fingerprint_profiles?.length || 0}`, action: "fingerprint-profiles" },
    { label: "OTA Updates", value: config.ota?.enabled ? "Enabled" : "Disabled", action: "ota" },
    { label: "Apply / Deploy", value: "", action: "deploy" },
    { label: "Device Name", value: config.device_name || "GeoBox", action: null },
  ];

  let html = "";
  rows.forEach((row) => {
    const chevron = row.action ? `<span class="settings-chevron">›</span>` : "";
    const value = row.value ? `<span class="settings-value">${escapeHtml(row.value)}</span>` : "";

    html += `
      <button class="settings-row" ${row.action ? `data-action="${row.action}"` : ""} style="width: 100%; text-align: left;">
        <span class="settings-label">${escapeHtml(row.label)}</span>
        ${value}${chevron}
      </button>
    `;
  });

  html += `
    <div style="margin-top: 16px;">
      <button class="action-btn primary" id="mobile-btn-save" style="width: 100%;">Save Configuration</button>
    </div>
  `;

  container.innerHTML = html;

  // Wire up settings row clicks
  container.querySelectorAll("[data-action]").forEach((row) => {
    row.addEventListener("click", () => {
      const action = row.dataset.action;
      handleSettingsAction(action);
    });
  });

  // Wire up save button
  const btnSave = document.getElementById("mobile-btn-save");
  if (btnSave) {
    btnSave.addEventListener("click", () => saveConfig().catch(handleError));
  }
}

function handleSettingsAction(action) {
  const data = getCurrentData();

  switch (action) {
    case "vpn-profiles":
      renderVPNProfilesEditor(data);
      break;
    case "vpn-units":
      navigateTo("vpn");
      renderVPNScreen(data);
      break;
    case "fingerprint-profiles":
      renderFingerprintProfilesEditor(data);
      break;
    case "ota":
      renderOTAEditor(data);
      break;
    case "deploy":
      navigateTo("system");
      renderSystemScreen(data);
      break;
  }
}

function renderVPNProfilesEditor(data) {
  const container = document.getElementById("settings-list");
  if (!container) return;

  const config = data?.config || {};
  const profiles = config.vpn_profiles || [];

  let html = `
    <button class="back-btn" data-back-settings style="margin-bottom: 16px;">← Back to Settings</button>
    <h3 style="margin-bottom: 12px;">VPN Profiles</h3>
    <button class="action-btn primary" id="btn-add-vpn-profile" style="width: 100%; margin-bottom: 16px;">+ Add Profile</button>
  `;

  if (profiles.length === 0) {
    html += `<div class="empty-state">No VPN profiles configured.</div>`;
  } else {
    profiles.forEach((profile, index) => {
      html += `
        <div class="card" style="margin-bottom: 8px;">
          <div class="card-header">
            <div>
              <div class="card-title">${escapeHtml(profile.name || profile.id)}</div>
              <div class="card-meta">${escapeHtml(profile.protocol)} · ${escapeHtml(profile.endpoint || "No endpoint")}</div>
            </div>
            <button class="action-btn" onclick="window.ui?.removeItem('vpn_profiles', ${index})" style="color: var(--error);">Delete</button>
          </div>
        </div>
      `;
    });
  }

  container.innerHTML = html;

  // Wire up back button
  const backBtn = container.querySelector("[data-back-settings]");
  if (backBtn) {
    backBtn.addEventListener("click", () => {
      navigateTo("settings");
      renderSettingsScreen(getCurrentData());
    });
  }

  // Wire up add button
  const addBtn = document.getElementById("btn-add-vpn-profile");
  if (addBtn) {
    addBtn.addEventListener("click", () => {
      withDraft((draft) => {
        addVPNProfileDraft(draft);
        showToast("VPN profile added");
        renderVPNProfilesEditor(getCurrentData());
      });
    });
  }
}

function renderFingerprintProfilesEditor(data) {
  const container = document.getElementById("settings-list");
  if (!container) return;

  const config = data?.config || {};
  const profiles = config.fingerprint_profiles || [];

  let html = `
    <button class="back-btn" data-back-settings style="margin-bottom: 16px;">← Back to Settings</button>
    <h3 style="margin-bottom: 12px;">Fingerprint Profiles</h3>
    <button class="action-btn primary" id="btn-add-fp-profile" style="width: 100%; margin-bottom: 16px;">+ Add Profile</button>
  `;

  if (profiles.length === 0) {
    html += `<div class="empty-state">No fingerprint profiles configured.</div>`;
  } else {
    profiles.forEach((profile, index) => {
      html += `
        <div class="card" style="margin-bottom: 8px;">
          <div class="card-header">
            <div>
              <div class="card-title">${escapeHtml(profile.preset || profile.id)}</div>
              <div class="card-meta">TTL: ${profile.ttl} · Window: ${profile.window_size}</div>
            </div>
            <button class="action-btn" onclick="window.ui?.removeItem('fingerprint_profiles', ${index})" style="color: var(--error);">Delete</button>
          </div>
        </div>
      `;
    });
  }

  container.innerHTML = html;

  // Wire up back button
  const backBtn = container.querySelector("[data-back-settings]");
  if (backBtn) {
    backBtn.addEventListener("click", () => {
      navigateTo("settings");
      renderSettingsScreen(getCurrentData());
    });
  }

  // Wire up add button
  const addBtn = document.getElementById("btn-add-fp-profile");
  if (addBtn) {
    addBtn.addEventListener("click", () => {
      withDraft((draft) => {
        draft.fingerprint_profiles.push({
          id: nextID("fp", draft.fingerprint_profiles),
          preset: "custom",
          ttl: 64,
          window_size: 65535,
          df: true,
          ecn: false,
          options: [],
        });
        showToast("Fingerprint profile added");
        renderFingerprintProfilesEditor(getCurrentData());
      });
    });
  }
}

function renderOTAEditor(data) {
  const container = document.getElementById("settings-list");
  if (!container) return;

  const config = data?.config || {};
  const ota = config.ota || {};

  let html = `
    <button class="back-btn" data-back-settings style="margin-bottom: 16px;">← Back to Settings</button>
    <h3 style="margin-bottom: 12px;">OTA Updates</h3>
    <div class="settings-list">
      <div class="settings-row">
        <span class="settings-label">Enabled</span>
        <span class="settings-value">${ota.enabled ? "Yes" : "No"}</span>
      </div>
      <div class="settings-row">
        <span class="settings-label">Channel</span>
        <span class="settings-value">${escapeHtml(ota.channel || "stable")}</span>
      </div>
      <div class="settings-row">
        <span class="settings-label">Current Version</span>
        <span class="settings-value">${escapeHtml(ota.current_version || "Unknown")}</span>
      </div>
      <div class="settings-row">
        <span class="settings-label">Auto Check</span>
        <span class="settings-value">Every ${ota.auto_check_hours || 24} hours</span>
      </div>
    </div>
  `;

  container.innerHTML = html;

  // Wire up back button
  const backBtn = container.querySelector("[data-back-settings]");
  if (backBtn) {
    backBtn.addEventListener("click", () => {
      navigateTo("settings");
      renderSettingsScreen(getCurrentData());
    });
  }
}

// System Screen
function renderSystemScreen(data) {
  const container = document.getElementById("system-content");
  if (!container) return;

  const runtime = data?.runtime || {};
  const config = data?.config || {};
  const hostFacts = runtime.host_facts || {};
  const deps = hostFacts.dependencies || { present: {}, missing: {} };
  const missingCount = Object.keys(deps.missing || {}).length;

  const rows = [
    { label: "Device Name", value: config.device_name || "GeoBox" },
    { label: "Uptime", value: runtime.started_at ? formatUptime(runtime.started_at) : "Unknown" },
    { label: "Controller", value: runtime.controller_status || "Unknown" },
    { label: "Last Reconcile", value: runtime.last_reconcile_at || "Never" },
    { label: "Missing Dependencies", value: missingCount > 0 ? `${missingCount}` : "None" },
  ];

  let html = '<div class="settings-list">';
  rows.forEach((row) => {
    html += `
      <div class="settings-row">
        <span class="settings-label">${escapeHtml(row.label)}</span>
        <span class="settings-value ${row.label === "Missing Dependencies" && missingCount > 0 ? "text-error" : ""}">${escapeHtml(row.value)}</span>
      </div>
    `;
  });
  html += "</div>";

  // Action buttons
  html += `
    <div style="margin-top: 16px; display: flex; flex-direction: column; gap: 8px;">
      <button class="action-btn primary" id="mobile-btn-apply" style="width: 100%;">Apply Changes</button>
      <button class="action-btn" id="mobile-btn-reconcile" style="width: 100%;">Reconcile</button>
      <button class="action-btn" id="mobile-btn-refresh" style="width: 100%;">Refresh</button>
      ${missingCount > 0 ? `<button class="action-btn" id="mobile-btn-install" style="width: 100%;">Install Dependencies</button>` : ""}
    </div>
  `;

  container.innerHTML = html;

  // Wire up buttons
  const btnApply = document.getElementById("mobile-btn-apply");
  if (btnApply) {
    btnApply.addEventListener("click", () => runApply(false).catch(handleError));
  }

  const btnReconcile = document.getElementById("mobile-btn-reconcile");
  if (btnReconcile) {
    btnReconcile.addEventListener("click", () => runReconcile().catch(handleError));
  }

  const btnRefresh = document.getElementById("mobile-btn-refresh");
  if (btnRefresh) {
    btnRefresh.addEventListener("click", async () => {
      try {
        await refreshAll(true);
        refreshCurrentScreen();
      } catch (err) {
        handleError(err);
      }
    });
  }

  const btnInstall = document.getElementById("mobile-btn-install");
  if (btnInstall) {
    btnInstall.addEventListener("click", () => runApply(true).catch(handleError));
  }
}

// Network Screen
function renderNetworkScreen(data) {
  const container = document.getElementById("network-list");
  if (!container) return;

  const config = data?.config || {};
  const bridges = config.bridges || [];

  if (bridges.length === 0) {
    container.innerHTML = `<div class="empty-state">No bridges configured.</div>`;
    return;
  }

  let html = "";
  bridges.forEach((bridge) => {
    html += `
      <div class="card">
        <div class="card-header">
          <div>
            <div class="card-title">${escapeHtml(bridge.name || bridge.id)}</div>
            <div class="card-meta">${escapeHtml(bridge.subnet || "")} • DHCP: ${escapeHtml(bridge.dhcp_start || "off")}-${escapeHtml(bridge.dhcp_end || "")}</div>
          </div>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

// Fingerprint Screen
function renderFingerprintScreen(data) {
  const container = document.getElementById("fingerprint-content");
  if (!container) return;

  const config = data?.config || {};
  const profiles = config.fingerprint_profiles || [];
  const policies = config.fingerprint_policies || [];

  let html = '<div class="settings-list">';
  html += `
    <div class="settings-row">
      <span class="settings-label">Profiles</span>
      <span class="settings-value">${profiles.length}</span>
    </div>
    <div class="settings-row">
      <span class="settings-label">Policies</span>
      <span class="settings-value">${policies.length}</span>
    </div>
  `;
  html += "</div>";

  container.innerHTML = html;
}

// Screen Router
function renderScreen(screenId, data) {
  switch (screenId) {
    case "vpn":
      renderVPNScreen(data);
      break;
    case "wifi":
      renderWiFiScreen(data);
      break;
    case "network":
      renderNetworkScreen(data);
      break;
    case "clients":
      renderClientsScreen(data);
      break;
    case "system":
      renderSystemScreen(data);
      break;
    case "fingerprint":
      renderFingerprintScreen(data);
      break;
    case "settings":
      renderSettingsScreen(data);
      break;
    default:
      console.warn("Unknown screen:", screenId);
  }
}

function normalizeRuntimeState(input = {}) {
  const hostFacts = input.host_facts || {};
  const dependencies = hostFacts.dependencies || {};
  const telemetry = hostFacts.telemetry || {};
  return {
    ...input,
    controller_status: input.controller_status || "unknown",
    vpn_units: input.vpn_units || {},
    wifi_networks: input.wifi_networks || {},
    clients: Array.isArray(input.clients) ? input.clients : [],
    host_facts: {
      ...hostFacts,
      telemetry: {
        clients: telemetry.clients || { available: false, reason: "not_yet_measured" },
        wifi_runtime: telemetry.wifi_runtime || { available: false, reason: "not_yet_measured" },
        vpn_throughput: telemetry.vpn_throughput || { available: false, reason: "not_yet_measured" },
      },
      dependencies: {
        present: dependencies.present || {},
        missing: dependencies.missing || {},
      },
    },
  };
}

function normalizeProfile(profile = {}) {
  return {
    id: profile.id || "",
    name: profile.name || "",
    protocol: profile.protocol || "wireguard",
    endpoint: profile.endpoint || "",
    username: profile.username || "",
    password: profile.password || "",
    config_blob: profile.config_blob || "",
    auto_reconnect: profile.auto_reconnect !== false,
    reconnect_attempts: Number(profile.reconnect_attempts || 0),
    reconnect_interval_seconds: Number(profile.reconnect_interval_seconds || 0),
    dns: {
      mode: profile.dns?.mode || "default",
      servers: Array.isArray(profile.dns?.servers) ? profile.dns.servers : [],
    },
    leak_protection: {
      dns_intercept: profile.leak_protection?.dns_intercept !== false,
      webrtc_mode: profile.leak_protection?.webrtc_mode || "auto",
      kill_switch: profile.leak_protection?.kill_switch !== false,
      ipv6_block: profile.leak_protection?.ipv6_block !== false,
      strip_edns_client_subnet: profile.leak_protection?.strip_edns_client_subnet !== false,
      mdns_block: profile.leak_protection?.mdns_block !== false,
      icmp_filter: profile.leak_protection?.icmp_filter !== false,
      ntp_redirect: profile.leak_protection?.ntp_redirect !== false,
    },
    tls_fingerprint: profile.tls_fingerprint || "chrome",
  };
}

function normalizeConfig(cfg = {}) {
  return {
    device_name: cfg.device_name || "GeoBox",
    http_port: Number(cfg.http_port || 80),
    websocket_path: cfg.websocket_path || "/ws",
    bridges: Array.isArray(cfg.bridges) ? cfg.bridges : [],
    vpn_profiles: Array.isArray(cfg.vpn_profiles) ? cfg.vpn_profiles.map(normalizeProfile) : [],
    vpn_units: Array.isArray(cfg.vpn_units) ? cfg.vpn_units : [],
    wifi_networks: Array.isArray(cfg.wifi_networks) ? cfg.wifi_networks : [],
    fingerprint_profiles: Array.isArray(cfg.fingerprint_profiles) ? cfg.fingerprint_profiles : [],
    fingerprint_policies: Array.isArray(cfg.fingerprint_policies) ? cfg.fingerprint_policies : [],
    ota: {
      enabled: cfg.ota?.enabled ?? false,
      channel: cfg.ota?.channel || "stable",
      current_version: cfg.ota?.current_version || "",
      update_url: cfg.ota?.update_url || "",
      auto_check_hours: Number(cfg.ota?.auto_check_hours || 24),
    },
  };
}

function getVPNProfileUIKey(profile) {
  if (!profile) {
    return null;
  }
  if (!profile[VPN_PROFILE_UI_KEY]) {
    Object.defineProperty(profile, VPN_PROFILE_UI_KEY, {
      value: `vpn-ui-${nextVPNProfileUIKey}`,
      enumerable: false,
      configurable: false,
      writable: false,
    });
    nextVPNProfileUIKey += 1;
  }
  return profile[VPN_PROFILE_UI_KEY];
}

function primeVPNProfileUIKeys(profiles = []) {
  profiles.forEach((profile) => {
    getVPNProfileUIKey(profile);
  });
}

function getVPNProfiles() {
  return state.draftConfig?.vpn_profiles || [];
}

function syncSelectedVPNProfileID(fallbackToFirst = true) {
  const profiles = getVPNProfiles();
  if (!profiles.length) {
    state.selectedVPNProfileID = null;
    return;
  }
  primeVPNProfileUIKeys(profiles);
  const selectedExists = profiles.some((profile) => getVPNProfileUIKey(profile) === state.selectedVPNProfileID);
  if (!selectedExists && fallbackToFirst) {
    state.selectedVPNProfileID = getVPNProfileUIKey(profiles[0]);
  }
}

function setSelectedVPNProfileID(profileID) {
  state.selectedVPNProfileID = profileID || null;
}

function toggleVPNProfileAdvanced(profileID) {
  const key = profileID || "";
  state.vpnProfileAdvancedOpen[key] = !state.vpnProfileAdvancedOpen[key];
  if (isBrowser) {
    renderVPNEditor();
  }
}

const VPN_PROTECTION_FLAGS = [
  {
    label: () => "Auto reconnect",
    enabled: (profile) => profile.auto_reconnect,
  },
  {
    label: () => "Kill switch",
    enabled: (_, protection) => protection.kill_switch !== false,
  },
  {
    label: () => "DNS intercept",
    enabled: (_, protection) => protection.dns_intercept !== false,
  },
  {
    label: () => "IPv6 block",
    enabled: (_, protection) => protection.ipv6_block !== false,
  },
  {
    label: () => "Strip ECS",
    enabled: (_, protection) => protection.strip_edns_client_subnet !== false,
  },
  {
    label: () => "mDNS block",
    enabled: (_, protection) => protection.mdns_block !== false,
  },
  {
    label: () => "ICMP filter",
    enabled: (_, protection) => protection.icmp_filter !== false,
  },
  {
    label: () => "NTP redirect",
    enabled: (_, protection) => protection.ntp_redirect !== false,
  },
  {
    label: (_, protection) => `WebRTC ${protection.webrtc_mode}`,
    enabled: (_, protection) => Boolean(protection.webrtc_mode && protection.webrtc_mode !== "auto"),
  },
];

function summarizeVPNProtection(profile) {
  const protection = profile.leak_protection || {};
  const items = VPN_PROTECTION_FLAGS.flatMap((flag) => (flag.enabled(profile, protection) ? [flag.label(profile, protection)] : []));
  if (!items.length) {
    return "No extra protections";
  }
  const visible = items.slice(0, 3);
  return items.length > 3 ? `${visible.join(" · ")} · +${items.length - 3} more` : visible.join(" · ");
}

function createDefaultVPNProfile(id, name = "New VPN Profile") {
  return {
    id: id || "",
    name,
    protocol: "wireguard",
    endpoint: "",
    username: "",
    password: "",
    config_blob: "",
    auto_reconnect: true,
    reconnect_attempts: 3,
    reconnect_interval_seconds: 5,
    dns: { mode: "cloudflare_doh", servers: ["1.1.1.1", "1.0.0.1"] },
    leak_protection: {
      dns_intercept: true,
      webrtc_mode: "spoof",
      kill_switch: true,
      ipv6_block: true,
      strip_edns_client_subnet: true,
      mdns_block: true,
      icmp_filter: true,
      ntp_redirect: true,
    },
    tls_fingerprint: "chrome",
  };
}

function addVPNProfileDraft(draft) {
  const newProfile = createDefaultVPNProfile(nextID("vpn", draft.vpn_profiles));
  draft.vpn_profiles.push(newProfile);
  setSelectedVPNProfileID(getVPNProfileUIKey(newProfile));
  return newProfile;
}

function removeVPNProfileDraft(draft, index) {
  const removedProfile = draft.vpn_profiles[index];
  if (!removedProfile) {
    return;
  }
  const removedProfileKey = getVPNProfileUIKey(removedProfile);
  const nextProfileKey = getVPNProfileUIKey(draft.vpn_profiles[index + 1]);
  const previousProfileKey = getVPNProfileUIKey(draft.vpn_profiles[index - 1]);
  if (state.selectedVPNProfileID === removedProfileKey) {
    setSelectedVPNProfileID(nextProfileKey || previousProfileKey);
  }
  if (removedProfileKey) {
    delete state.vpnProfileAdvancedOpen[removedProfileKey];
  }
  draft.vpn_profiles.splice(index, 1);
  syncSelectedVPNProfileID(false);
}

function renderVPNProfileCard(profile, index) {
  const profileKey = getVPNProfileUIKey(profile);
  const isSelected = state.selectedVPNProfileID === profileKey;
  return `
    <article class="card vpn-profile-card ${isSelected ? "selected" : ""}">
      <div class="panel-head">
        <div>
          <h4>${escapeHtml(profile.name || profile.id)}</h4>
          <p>${escapeHtml(profile.protocol)} · ${escapeHtml(displayUnknown(profile.endpoint, "Endpoint not set"))}</p>
        </div>
        <button class="button button-danger" onclick="ui.removeItem('vpn_profiles', ${index})">Delete</button>
      </div>
      <p class="vpn-profile-summary">${escapeHtml(summarizeVPNProtection(profile))}</p>
      <div class="pill-row">
        <span class="pill">${escapeHtml(profile.protocol)}</span>
        ${isSelected ? `<span class="pill">Selected</span>` : ""}
        <span class="pill">${escapeHtml(profile.leak_protection?.webrtc_mode || "auto")} WebRTC</span>
      </div>
      <div class="action-row">
        <button class="button button-ghost" type="button" onclick="ui.selectVPNProfile('${escapeJSString(profileKey)}')">
          ${isSelected ? "Selected profile" : "Open details"}
        </button>
      </div>
    </article>
  `;
}

function renderVPNProfileEditor(profile, index) {
  const profileKey = getVPNProfileUIKey(profile);
  return `
    <article class="card vpn-profile-detail-card">
      <div class="panel-head">
        <div>
          <h4>${escapeHtml(profile.name || profile.id || "VPN Profile")}</h4>
          <p>${escapeHtml(profile.protocol)} · ${escapeHtml(displayUnknown(profile.endpoint, "Endpoint not set"))}</p>
        </div>
        <button class="button button-danger" onclick="ui.removeItem('vpn_profiles', ${index})">Delete</button>
      </div>
      <div class="form-grid">
        ${field("ID", profile.id, `ui.update('vpn_profiles', ${index}, 'id', this.value)`)}
        ${field("Name", profile.name, `ui.update('vpn_profiles', ${index}, 'name', this.value)`)}
        ${selectField("Protocol", PROTOCOLS, profile.protocol, `ui.update('vpn_profiles', ${index}, 'protocol', this.value)`)}
        ${field("Endpoint", profile.endpoint, `ui.update('vpn_profiles', ${index}, 'endpoint', this.value)`)}
        ${field("Username", profile.username || "", `ui.update('vpn_profiles', ${index}, 'username', this.value)`)}
        ${field("Password", profile.password || "", `ui.update('vpn_profiles', ${index}, 'password', this.value)`)}
        ${field("Reconnect Attempts", profile.reconnect_attempts, `ui.updateNumber('vpn_profiles', ${index}, 'reconnect_attempts', this.value)`)}
        ${field("Reconnect Interval", profile.reconnect_interval_seconds, `ui.updateNumber('vpn_profiles', ${index}, 'reconnect_interval_seconds', this.value)`)}
        ${selectField("DNS Mode", DNS_MODES, profile.dns.mode, `ui.update('vpn_profiles', ${index}, 'dns.mode', this.value)`)}
        ${field("DNS Servers", (profile.dns.servers || []).join(", "), `ui.updateList('vpn_profiles', ${index}, 'dns.servers', this.value)`)}
        ${selectField("WebRTC", WEBRTC_MODES, profile.leak_protection.webrtc_mode, `ui.update('vpn_profiles', ${index}, 'leak_protection.webrtc_mode', this.value)`)}
        ${profile.protocol === "socks5" ? `
          <div class="field">
            <label>TLS Fingerprint</label>
            <div class="muted">Not used for SOCKS5 profiles.</div>
          </div>
        ` : selectField("TLS Fingerprint", TLS_FINGERPRINTS, profile.tls_fingerprint, `ui.update('vpn_profiles', ${index}, 'tls_fingerprint', this.value)`)}
        <div class="field full">
          <label>Protection</label>
          <div class="toggle-row">
            ${toggle("Auto Reconnect", profile.auto_reconnect, `ui.toggle('vpn_profiles', ${index}, 'auto_reconnect', this.checked)`)}
            ${toggle("Kill Switch", profile.leak_protection.kill_switch, `ui.toggle('vpn_profiles', ${index}, 'leak_protection.kill_switch', this.checked)`)}
            ${toggle("DNS Intercept", profile.leak_protection.dns_intercept, `ui.toggle('vpn_profiles', ${index}, 'leak_protection.dns_intercept', this.checked)`)}
            ${toggle("IPv6 Block", profile.leak_protection.ipv6_block, `ui.toggle('vpn_profiles', ${index}, 'leak_protection.ipv6_block', this.checked)`)}
            ${toggle("Strip ECS", profile.leak_protection.strip_edns_client_subnet, `ui.toggle('vpn_profiles', ${index}, 'leak_protection.strip_edns_client_subnet', this.checked)`)}
          </div>
        </div>
        <div class="field full">
          <label>Advanced</label>
          <button class="button button-ghost" type="button" onclick="ui.toggleVPNProfileAdvanced('${escapeJSString(profileKey)}')">
            ${state.vpnProfileAdvancedOpen[profileKey || ""] ? "Hide raw config_blob" : "Show raw config_blob"}
          </button>
        </div>
        ${state.vpnProfileAdvancedOpen[profileKey || ""] ? `
          <div class="field full">
            <label>Protocol Config Blob</label>
            <textarea oninput="ui.update('vpn_profiles', ${index}, 'config_blob', this.value)">${escapeHtml(profile.config_blob || "")}</textarea>
          </div>
        ` : ""}
        <div class="field full">
          <label>Selection</label>
          <div class="toggle-row">
            <button class="button button-ghost" type="button" onclick="ui.selectVPNProfile('${escapeJSString(profileKey)}')">
              ${state.selectedVPNProfileID === profileKey ? "Selected profile" : "Select profile"}
            </button>
          </div>
        </div>
      </div>
    </article>
  `;
}

function normalizeDashboard(payload = {}) {
  return {
    ...payload,
    config: normalizeConfig(payload.config || {}),
    state: normalizeRuntimeState(payload.state || {}),
    lxc: payload.lxc || {},
  };
}

function setByPath(target, path, value) {
  const parts = path.split(".");
  let current = target;
  for (let i = 0; i < parts.length - 1; i += 1) {
    current = current[parts[i]];
  }
  current[parts[parts.length - 1]] = value;
}

function nextID(prefix, items) {
  const existing = new Set((items || []).map((item) => item.id));
  let index = (items || []).length + 1;
  let candidate = `${prefix}-${index}`;
  while (existing.has(candidate)) {
    index += 1;
    candidate = `${prefix}-${index}`;
  }
  return candidate;
}

function showToast(message, type = "success") {
  state.toast = { message, type };
  renderToast();
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => {
    state.toast = null;
    renderToast();
  }, 3000);
}

function renderToast() {
  const toast = document.getElementById("toast");
  if (!state.toast) {
    toast.className = "toast hidden";
    toast.textContent = "";
    return;
  }
  toast.className = `toast ${state.toast.type}`;
  toast.textContent = state.toast.message;
}

function markDirty(value) {
  state.dirty = value;
  const badge = document.getElementById("dirty-badge");
  badge.textContent = value ? "unsaved changes" : "saved";
  badge.className = value ? "badge badge-warn" : "badge";
}

function withDraft(mutator) {
  if (!state.draftConfig) {
    showToast("Configuration is still loading.", "error");
    return;
  }
  mutator(state.draftConfig);
  markDirty(true);
  renderAll();
}

function field(label, value, handler, full = false) {
  return `
    <div class="field ${full ? "full" : ""}">
      <label>${escapeHtml(label)}</label>
      <input value="${escapeHtml(value)}" oninput="${handler}">
    </div>
  `;
}

function selectField(label, items, value, handler, allowEmpty = false) {
  const options = allowEmpty ? ["", ...items] : items;
  return `
    <div class="field">
      <label>${escapeHtml(label)}</label>
      <select onchange="${handler}">
        ${options.map((item) => `<option value="${escapeHtml(item)}" ${item === value ? "selected" : ""}>${escapeHtml(item || "None")}</option>`).join("")}
      </select>
    </div>
  `;
}

function toggle(label, checked, handler) {
  return `
    <label class="toggle">
      <input type="checkbox" ${checked ? "checked" : ""} onchange="${handler}">
      <span>${escapeHtml(label)}</span>
    </label>
  `;
}

function renderSidebarSummary() {
  const cfg = state.draftConfig;
  const runtime = state.dashboard.state;
  document.getElementById("sidebar-summary").innerHTML = `
    <p class="eyebrow">Quick Status</p>
    <div class="stack">
      <div>
        <strong>${escapeHtml(cfg.device_name)}</strong>
        <p class="muted">Controller ${escapeHtml(runtime.controller_status)}</p>
      </div>
      <div class="pill-row">
        <span class="pill">${cfg.bridges.length} bridges</span>
        <span class="pill">${cfg.vpn_profiles.length} profiles</span>
        <span class="pill">${cfg.vpn_units.length} units</span>
      </div>
      <div class="pill-row">
        <span class="pill">${cfg.wifi_networks.length} Wi-Fi</span>
        <span class="pill">${cfg.fingerprint_policies.length} policies</span>
      </div>
    </div>
  `;
}

function renderMetrics() {
  const cfg = state.draftConfig;
  const runtime = state.dashboard.state;
  const missingDeps = Object.keys(runtime.host_facts.dependencies?.missing || {}).length;
  const clientTelemetry = runtime.host_facts.telemetry?.clients || { available: false };
  const clientCount = clientTelemetry.available ? String(runtime.clients.length) : "Unknown";
  document.getElementById("metrics").innerHTML = `
    <article class="metric-card"><span>VPN Units</span><strong>${cfg.vpn_units.length}</strong></article>
    <article class="metric-card"><span>Wi-Fi Networks</span><strong>${cfg.wifi_networks.length}</strong></article>
    <article class="metric-card"><span>Connected Clients</span><strong>${clientCount}</strong></article>
    <article class="metric-card"><span>Missing Dependencies</span><strong>${missingDeps}</strong></article>
  `;
}

function renderOverview() {
  const cfg = state.draftConfig;
  const runtime = state.dashboard.state;
  const unitCards = Object.values(runtime.vpn_units || {});
  const telemetry = runtime.host_facts.telemetry || {};
  const clientTelemetry = telemetry.clients || { available: false };
  const throughputTelemetry = telemetry.vpn_throughput || { available: false };
  document.getElementById("overview-runtime").innerHTML = `
    <div class="split">
      <div class="card">
        <h4>Topology</h4>
        <div class="stack" style="margin-top: 14px;">
          ${cfg.bridges.map((bridge) => `
            <div>
              <strong>${escapeHtml(bridge.name)}</strong>
              <p>${escapeHtml(bridge.subnet)} · gateway ${escapeHtml(bridge.gateway)}</p>
              <div class="pill-row">
                ${cfg.wifi_networks.filter((item) => item.bridge_id === bridge.id).map((item) => `<span class="pill">Wi-Fi ${escapeHtml(item.ssid)}</span>`).join("")}
                ${cfg.vpn_units.filter((item) => item.bridge_id === bridge.id).map((item) => `<span class="pill">Unit ${escapeHtml(item.name)}</span>`).join("")}
              </div>
            </div>
          `).join("") || `<div class="empty">No bridges configured.</div>`}
        </div>
      </div>
      <div class="card">
        <h4>Live Units</h4>
        <div class="stack" style="margin-top: 14px;">
          ${unitCards.map((unit) => `
            <div>
              <strong>${escapeHtml(unit.name)}</strong>
              <p>${escapeHtml(unit.state || unit.status || "unknown")} · ${escapeHtml(unit.bridge_id)}</p>
              <div class="pill-row">
                ${unit.ip ? `<span class="pill">${escapeHtml(unit.ip)}</span>` : ""}
                <span class="pill">${escapeHtml(unit.profile_id)}</span>
                ${throughputTelemetry.available ? "" : `<span class="pill">Throughput unknown</span>`}
              </div>
            </div>
          `).join("") || `<div class="empty">No unit runtime data.</div>`}
        </div>
      </div>
    </div>
    <div class="card" style="margin-top: 16px;">
      <h4>Connected Clients</h4>
      ${runtime.clients.length ? `
        <table>
          <thead>
            <tr><th>Hostname</th><th>IP</th><th>MAC</th><th>Bridge</th><th>Adapter</th><th>Signal</th><th>Source</th><th>Last Seen</th></tr>
          </thead>
          <tbody>
            ${runtime.clients.map((client) => `
              <tr>
                <td>${escapeHtml(displayUnknown(client.hostname))}</td>
                <td>${escapeHtml(displayUnknown(client.ip))}</td>
                <td>${escapeHtml(client.mac)}</td>
                <td>${escapeHtml(displayUnknown(client.bridge_id))}</td>
                <td>${escapeHtml(displayUnknown(client.adapter))}</td>
                <td>${escapeHtml(displayUnknown(client.signal_dbm, "Not yet measured"))}</td>
                <td>${escapeHtml(displayUnknown(client.source))}</td>
                <td>${escapeHtml(displayUnknown(client.last_seen, "Not yet measured"))}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      ` : clientTelemetry.available ? `<div class="empty">No live clients reported yet.</div>` : `<div class="empty">Client telemetry is not yet measured on this host.</div>`}
    </div>
  `;
}

function renderNetworkEditor() {
  const cfg = state.draftConfig;
  document.getElementById("network-editor").innerHTML = `
    <div class="stack">
      ${cfg.bridges.map((bridge, index) => `
        <article class="card">
          <div class="panel-head">
            <div><h4>${escapeHtml(bridge.name || bridge.id)}</h4><p>${escapeHtml(bridge.subnet)}</p></div>
            <button class="button button-danger" onclick="ui.removeItem('bridges', ${index})">Delete</button>
          </div>
          <div class="form-grid">
            ${field("ID", bridge.id, `ui.update('bridges', ${index}, 'id', this.value)`)}
            ${field("Name", bridge.name, `ui.update('bridges', ${index}, 'name', this.value)`)}
            ${field("Subnet", bridge.subnet, `ui.update('bridges', ${index}, 'subnet', this.value)`)}
            ${field("Gateway", bridge.gateway, `ui.update('bridges', ${index}, 'gateway', this.value)`)}
            ${field("DHCP Start", bridge.dhcp_start, `ui.update('bridges', ${index}, 'dhcp_start', this.value)`)}
            ${field("DHCP End", bridge.dhcp_end, `ui.update('bridges', ${index}, 'dhcp_end', this.value)`)}
            ${field("Lease Time", bridge.lease_time, `ui.update('bridges', ${index}, 'lease_time', this.value)`)}
            ${selectField("Upstream Bridge", cfg.bridges.map((item) => item.id).filter((id) => id !== bridge.id), bridge.upstream_bridge || "", `ui.update('bridges', ${index}, 'upstream_bridge', this.value)`, true)}
          </div>
        </article>
      `).join("") || `<div class="empty">No bridges configured.</div>`}
      <article class="card">
        <h4>VPN Units</h4>
        <div class="stack" style="margin-top: 14px;">
          ${cfg.vpn_units.map((unit, index) => `
            <div class="card">
              <div class="panel-head">
                <div><h4>${escapeHtml(unit.name || unit.id)}</h4><p>${escapeHtml(unit.container_name)}</p></div>
                <button class="button button-danger" onclick="ui.removeItem('vpn_units', ${index})">Delete</button>
              </div>
              <div class="form-grid">
                ${field("ID", unit.id, `ui.update('vpn_units', ${index}, 'id', this.value)`)}
                ${field("Name", unit.name, `ui.update('vpn_units', ${index}, 'name', this.value)`)}
                ${field("Container Name", unit.container_name, `ui.update('vpn_units', ${index}, 'container_name', this.value)`)}
                ${field("Max Clients", unit.max_clients, `ui.updateNumber('vpn_units', ${index}, 'max_clients', this.value)`)}
                ${selectField("Bridge", cfg.bridges.map((item) => item.id), unit.bridge_id, `ui.update('vpn_units', ${index}, 'bridge_id', this.value)`)}
                ${selectField("VPN Profile", cfg.vpn_profiles.map((item) => item.id), unit.profile_id, `ui.update('vpn_units', ${index}, 'profile_id', this.value)`)}
                ${selectField("Upstream Bridge", cfg.bridges.map((item) => item.id), unit.upstream_bridge || "", `ui.update('vpn_units', ${index}, 'upstream_bridge', this.value)`, true)}
              </div>
            </div>
          `).join("") || `<div class="empty">No VPN units configured.</div>`}
        </div>
      </article>
    </div>
  `;
}

function renderVPNEditor() {
  const cfg = state.draftConfig;
  syncSelectedVPNProfileID(false);
  primeVPNProfileUIKeys(cfg.vpn_profiles);
  const selectedProfileIndex = cfg.vpn_profiles.findIndex((profile) => getVPNProfileUIKey(profile) === state.selectedVPNProfileID);
  const selectedProfile = selectedProfileIndex >= 0 ? cfg.vpn_profiles[selectedProfileIndex] : null;
  const selectedCardTitle = selectedProfile ? `${escapeHtml(selectedProfile.name || selectedProfile.id || "VPN Profile")}` : "Select a profile";
  const selectedDetail = selectedProfile ? renderVPNProfileEditor(selectedProfile, selectedProfileIndex) : `
    <div class="empty">
      Select a VPN profile to edit its full settings.
    </div>
  `;
  document.getElementById("vpn-editor").innerHTML = `
    <div class="vpn-editor-shell">
      <div class="card-grid vpn-profile-grid">
        ${cfg.vpn_profiles.map((profile, index) => renderVPNProfileCard(profile, index)).join("") || `<div class="empty">No VPN profiles configured.</div>`}
      </div>
      <div class="vpn-profile-detail">
        <div class="panel-head">
          <div>
            <h4>${selectedCardTitle}</h4>
            <p>${selectedProfile ? "Focused editor for the selected profile only." : "No profile selected yet."}</p>
          </div>
        </div>
        ${selectedDetail}
      </div>
    </div>
  `;
}

function renderWiFiEditor() {
  const cfg = state.draftConfig;
  document.getElementById("wifi-editor").innerHTML = cfg.wifi_networks.length ? `
    <div class="stack">
      ${cfg.wifi_networks.map((wifi, index) => `
        <article class="card">
          <div class="panel-head">
            <div><h4>${escapeHtml(wifi.name || wifi.id)}</h4><p>${escapeHtml(wifi.ssid)} · ${escapeHtml(wifi.bridge_id || "unbound")}</p></div>
            <button class="button button-danger" onclick="ui.removeItem('wifi_networks', ${index})">Delete</button>
          </div>
          <div class="form-grid">
            ${field("ID", wifi.id, `ui.update('wifi_networks', ${index}, 'id', this.value)`)}
            ${field("Name", wifi.name, `ui.update('wifi_networks', ${index}, 'name', this.value)`)}
            ${field("SSID", wifi.ssid, `ui.update('wifi_networks', ${index}, 'ssid', this.value)`)}
            ${field("Adapter", wifi.adapter || "", `ui.update('wifi_networks', ${index}, 'adapter', this.value)`)}
            ${selectField("Bridge", cfg.bridges.map((item) => item.id), wifi.bridge_id || "", `ui.update('wifi_networks', ${index}, 'bridge_id', this.value)`)}
            ${selectField("Band", WIFI_BANDS, wifi.band || "5g", `ui.update('wifi_networks', ${index}, 'band', this.value)`)}
            ${field("Channel", wifi.channel || 36, `ui.updateNumber('wifi_networks', ${index}, 'channel', this.value)`)}
            ${field("Channel Width", wifi.channel_width || 80, `ui.updateNumber('wifi_networks', ${index}, 'channel_width', this.value)`)}
            ${selectField("Mode", WIFI_MODES, wifi.mode || "ac", `ui.update('wifi_networks', ${index}, 'mode', this.value)`)}
            ${selectField("Security", WIFI_SECURITY, wifi.security || "wpa2", `ui.update('wifi_networks', ${index}, 'security', this.value)`)}
            ${field("Password", wifi.password || "", `ui.update('wifi_networks', ${index}, 'password', this.value)`)}
            ${selectField("WPS", ["disabled", "pin", "pbc"], wifi.wps_mode || "disabled", `ui.update('wifi_networks', ${index}, 'wps_mode', this.value)`)}
            <div class="field full"><label>Flags</label><div class="toggle-row">${toggle("Hidden SSID", !!wifi.hidden, `ui.toggle('wifi_networks', ${index}, 'hidden', this.checked)`)}</div></div>
          </div>
        </article>
      `).join("")}
    </div>
  ` : `<div class="empty">No Wi-Fi networks configured.</div>`;
}

function renderFingerprintEditor() {
  const cfg = state.draftConfig;
  document.getElementById("fingerprint-editor").innerHTML = `
    <div class="split">
      <div>
        <h4>Fingerprint Profiles</h4>
        <div class="stack" style="margin-top: 14px;">
          ${cfg.fingerprint_profiles.map((profile, index) => `
            <article class="card">
              <div class="panel-head">
                <div><h4>${escapeHtml(profile.preset || profile.id)}</h4><p>TTL ${escapeHtml(profile.ttl)} · Window ${escapeHtml(profile.window_size)}</p></div>
                <button class="button button-danger" onclick="ui.removeItem('fingerprint_profiles', ${index})">Delete</button>
              </div>
              <div class="form-grid">
                ${field("ID", profile.id, `ui.update('fingerprint_profiles', ${index}, 'id', this.value)`)}
                ${field("Preset", profile.preset, `ui.update('fingerprint_profiles', ${index}, 'preset', this.value)`)}
                ${field("TTL", profile.ttl, `ui.updateNumber('fingerprint_profiles', ${index}, 'ttl', this.value)`)}
                ${field("Window Size", profile.window_size, `ui.updateNumber('fingerprint_profiles', ${index}, 'window_size', this.value)`)}
                <div class="field full"><label>Flags</label><div class="toggle-row">${toggle("DF", !!profile.df, `ui.toggle('fingerprint_profiles', ${index}, 'df', this.checked)`)}${toggle("ECN", !!profile.ecn, `ui.toggle('fingerprint_profiles', ${index}, 'ecn', this.checked)`)}</div></div>
              </div>
            </article>
          `).join("") || `<div class="empty">No fingerprint profiles configured.</div>`}
        </div>
      </div>
      <div>
        <h4>Fingerprint Policies</h4>
        <div class="stack" style="margin-top: 14px;">
          ${cfg.fingerprint_policies.map((policy, index) => `
            <article class="card">
              <div class="panel-head">
                <div><h4>${escapeHtml(policy.name || policy.id)}</h4><p>${escapeHtml(policy.mac_address)} · ${escapeHtml(policy.bridge_id)}</p></div>
                <button class="button button-danger" onclick="ui.removeItem('fingerprint_policies', ${index})">Delete</button>
              </div>
              <div class="form-grid">
                ${field("ID", policy.id, `ui.update('fingerprint_policies', ${index}, 'id', this.value)`)}
                ${field("Name", policy.name, `ui.update('fingerprint_policies', ${index}, 'name', this.value)`)}
                ${field("MAC Address", policy.mac_address, `ui.update('fingerprint_policies', ${index}, 'mac_address', this.value)`)}
                ${selectField("Bridge", cfg.bridges.map((item) => item.id), policy.bridge_id, `ui.update('fingerprint_policies', ${index}, 'bridge_id', this.value)`)}
                ${selectField("Profile", cfg.fingerprint_profiles.map((item) => item.id), policy.fingerprint_profile_id, `ui.update('fingerprint_policies', ${index}, 'fingerprint_profile_id', this.value)`)}
              </div>
            </article>
          `).join("") || `<div class="empty">No fingerprint policies configured.</div>`}
        </div>
      </div>
    </div>
  `;
}

function renderSystemEditor() {
  const cfg = state.draftConfig;
  const runtime = state.dashboard.state;
  const lxc = state.dashboard.lxc || {};
  const deps = runtime.host_facts.dependencies || { present: {}, missing: {} };
  document.getElementById("system-editor").innerHTML = `
    <div class="split">
      <article class="card">
        <h4>OTA Settings</h4>
        <div class="form-grid" style="margin-top: 14px;">
          ${field("Channel", cfg.ota.channel, `ui.update('ota', null, 'channel', this.value)`)}
          ${field("Current Version", cfg.ota.current_version, `ui.update('ota', null, 'current_version', this.value)`)}
          ${field("Auto Check Hours", cfg.ota.auto_check_hours, `ui.updateNumber('ota', null, 'auto_check_hours', this.value)`)}
          ${field("Update URL", cfg.ota.update_url, `ui.update('ota', null, 'update_url', this.value)`, true)}
          <div class="field full"><label>Flags</label><div class="toggle-row">${toggle("Enabled", !!cfg.ota.enabled, `ui.toggle('ota', null, 'enabled', this.checked)`)}</div></div>
        </div>
      </article>
      <article class="card">
        <h4>Host Readiness</h4>
        <p>${Object.keys(deps.missing || {}).length ? "Some host dependencies are still missing." : "Host dependencies look complete."}</p>
        <div class="pill-row" style="margin-top: 12px;">
          ${Object.values(deps.present || {}).map((item) => `<span class="pill">${escapeHtml(item.binary)}</span>`).join("")}
        </div>
        ${Object.values(deps.missing || {}).length ? `<p style="margin-top: 12px;">Missing: ${Object.values(deps.missing).map((item) => escapeHtml(`${item.binary} (${item.package})`)).join(", ")}</p>` : ""}
      </article>
    </div>
    <div class="card" style="margin-top: 16px;">
      <h4>LXC Units</h4>
      <div class="stack" style="margin-top: 14px;">
        ${Object.values(lxc).map((item) => `
          <div class="card">
            <h4>${escapeHtml(item.name)}</h4>
            <p>${escapeHtml(item.container_name)} · ${escapeHtml(item.state)}</p>
            <div class="pill-row">
              ${item.ip ? `<span class="pill">${escapeHtml(item.ip)}</span>` : ""}
              <span class="pill">${item.defined ? "defined" : "undefined"}</span>
            </div>
            <div class="action-row">
              <button class="button button-ghost" onclick="ui.runLXCAction('${escapeJSString(item.id)}', 'ensure')">Ensure</button>
              <button class="button button-ghost" onclick="ui.runLXCAction('${escapeJSString(item.id)}', 'start')">Start</button>
              <button class="button button-ghost" onclick="ui.runLXCAction('${escapeJSString(item.id)}', 'stop')">Stop</button>
              <button class="button button-ghost" onclick="ui.runLXCAction('${escapeJSString(item.id)}', 'restart')">Restart</button>
            </div>
          </div>
        `).join("") || `<div class="empty">No LXC units available.</div>`}
      </div>
    </div>
    <div class="card" style="margin-top: 16px;">
      <h4>Operations Output</h4>
      <pre id="plan-output">${escapeHtml(state.planOutput)}</pre>
    </div>
  `;
}

function renderSectionVisibility() {
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.toggle("active", item.dataset.section === state.currentSection);
  });
  document.querySelectorAll(".section-panel").forEach((panel) => {
    panel.classList.toggle("active", panel.dataset.sectionPanel === state.currentSection);
  });
}

function renderTopbar() {
  const cfg = state.draftConfig;
  const runtime = state.dashboard.state;
  const pendingUpdate = runtime.pending_update_version || "Unknown";
  document.getElementById("device-title").textContent = cfg.device_name;
  document.getElementById("live-status-line").textContent = `Controller ${runtime.controller_status} · pending OTA ${pendingUpdate}`;
  document.getElementById("controller-badge").textContent = runtime.controller_status;
}

function renderAll() {
  if (!state.dashboard || !state.draftConfig) {
    return;
  }
  renderToast();
  renderTopbar();
  renderSidebarSummary();
  renderMetrics();
  renderOverview();
  renderNetworkEditor();
  renderVPNEditor();
  renderWiFiEditor();
  renderFingerprintEditor();
  renderSystemEditor();
  renderSectionVisibility();
}

async function hydrate() {
  const dashboard = normalizeDashboard(await fetchJson("/api/dashboard"));
  state.dashboard = dashboard;
  state.draftConfig = deepClone(dashboard.config);
  nextVPNProfileUIKey = 1;
  state.selectedVPNProfileID = null;
  state.vpnProfileAdvancedOpen = Object.create(null);
  markDirty(false);
  renderAll();
}

async function refreshAll(showMessage = true) {
  await hydrate();
  if (showMessage) {
    showToast("Configuration reloaded from controller.");
  }
}

async function saveConfig() {
  const saved = await fetchJson("/api/config", {
    method: "POST",
    body: JSON.stringify(state.draftConfig),
  });
  state.draftConfig = deepClone(normalizeConfig(saved));
  if (state.dashboard) {
    state.dashboard.config = deepClone(normalizeConfig(saved));
  }
  nextVPNProfileUIKey = 1;
  state.selectedVPNProfileID = null;
  state.vpnProfileAdvancedOpen = Object.create(null);
  markDirty(false);
  renderAll();
  showToast("Configuration saved.");
}

async function runReconcile() {
  const payload = await fetchJson("/api/reconcile", {
    method: "POST",
    body: JSON.stringify({ execute: false }),
  });
  state.planOutput = JSON.stringify(payload, null, 2);
  renderSystemEditor();
  showToast("Runtime plan rebuilt.");
}

async function runApply(installDependencies = false) {
  const payload = await fetchJson("/api/apply", {
    method: "POST",
    body: JSON.stringify({
      install_dependencies: installDependencies,
      use_sudo: true,
      reconcile: true,
    }),
  });
  state.planOutput = JSON.stringify(payload, null, 2);
  await hydrate();
  showToast(installDependencies ? "Install + apply completed." : "Apply completed.");
}

async function runLXCAction(unitID, action) {
  const payload = await fetchJson(`/api/lxc/${unitID}`, {
    method: "POST",
    body: JSON.stringify({ action, use_sudo: true }),
  });
  state.planOutput = JSON.stringify(payload, null, 2);
  state.dashboard.lxc = await fetchJson("/api/lxc");
  renderSystemEditor();
  showToast(`LXC action '${action}' completed.`);
}

// WebSocket state for reconnection management
let wsInstance = null;
let wsReconnectAttempts = 0;
const WS_MAX_RECONNECT_DELAY = 30000; // 30 seconds max
const WS_BASE_RECONNECT_DELAY = 1000; // 1 second base

// WebSocket for real-time updates
function setupWebSocket() {
  // Close existing connection if any
  if (wsInstance) {
    wsInstance.onclose = null; // Prevent reconnect loop
    wsInstance.onerror = null;
    wsInstance.close();
    wsInstance = null;
  }

  const protocol = window.location.protocol === "https:" ? "wss" : "ws";
  const wsPath = state.draftConfig?.websocket_path || "/ws";
  const wsUrl = `${protocol}://${window.location.host}${wsPath}`;

  wsInstance = new WebSocket(wsUrl);

  wsInstance.onmessage = (event) => {
    // Reset reconnect attempts on successful message
    wsReconnectAttempts = 0;

    // Null check for event data
    if (!event || !event.data) {
      return;
    }

    let update;
    try {
      update = JSON.parse(event.data);
    } catch (err) {
      console.error("WebSocket parse error:", err);
      return;
    }

    // Null check for parsed data
    if (!update) {
      return;
    }

    if (update.runtime) {
      state.dashboard = normalizeRuntimeState(update.runtime);
    }
    if (update.config) {
      state.draftConfig = normalizeConfig(update.config);
    }

    // Re-render current view
    const data = {
      config: state.draftConfig,
      runtime: state.dashboard,
    };

    if (state.currentScreen === "home") {
      renderHomeGrid(data);
    } else {
      renderScreen(state.currentScreen, data);
    }
  };

  wsInstance.onclose = () => {
    // Exponential backoff with jitter
    const delay = Math.min(
      WS_BASE_RECONNECT_DELAY * Math.pow(2, wsReconnectAttempts) + Math.random() * 1000,
      WS_MAX_RECONNECT_DELAY
    );
    wsReconnectAttempts++;

    console.log(`WebSocket closed, reconnecting in ${Math.round(delay / 1000)}s (attempt ${wsReconnectAttempts})`);
    setTimeout(setupWebSocket, delay);
  };

  wsInstance.onerror = (err) => {
    console.error("WebSocket connection error:", err);
  };

  wsInstance.onopen = () => {
    console.log("WebSocket connected");
    wsReconnectAttempts = 0; // Reset on successful connection
  };
}

function handleError(error) {
  showToast(error.message || String(error), "error");
}

const ui = {
  setSection(section) {
    state.currentSection = SECTIONS.includes(section) ? section : "overview";
    renderSectionVisibility();
  },
  update(section, index, path, value) {
    withDraft((draft) => {
      const target = index === null ? draft[section] : draft[section][index];
      setByPath(target, path, value);
    });
  },
  updateNumber(section, index, path, value) {
    ui.update(section, index, path, Number(value || 0));
  },
  updateList(section, index, path, value) {
    ui.update(section, index, path, value.split(",").map((item) => item.trim()).filter(Boolean));
  },
  toggle(section, index, path, checked) {
    ui.update(section, index, path, checked);
  },
  selectVPNProfile(profileID) {
    setSelectedVPNProfileID(profileID);
    renderVPNEditor();
  },
  toggleVPNProfileAdvanced(profileID) {
    toggleVPNProfileAdvanced(profileID);
  },
  removeItem(section, index) {
    withDraft((draft) => {
      if (section === "vpn_profiles") {
        removeVPNProfileDraft(draft, index);
        return;
      }
      draft[section].splice(index, 1);
    });
  },
  runLXCAction,
};

function attachHandlers() {
  if (handlersAttached) {
    return;
  }
  handlersAttached = true;
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("click", () => ui.setSection(item.dataset.section));
  });

  document.getElementById("btn-refresh").addEventListener("click", () => refreshAll(true).catch(handleError));
  document.getElementById("btn-save").addEventListener("click", () => saveConfig().catch(handleError));
  document.getElementById("btn-apply").addEventListener("click", () => runApply(false).catch(handleError));
  document.getElementById("btn-install-apply").addEventListener("click", () => runApply(true).catch(handleError));
  document.getElementById("btn-reconcile").addEventListener("click", () => runReconcile().catch(handleError));

  document.getElementById("btn-add-bridge").addEventListener("click", () => {
    withDraft((draft) => {
      draft.bridges.push({
        id: nextID("br", draft.bridges),
        name: "New Bridge",
        subnet: "192.168.40.0/24",
        gateway: "192.168.40.1",
        dhcp_start: "192.168.40.50",
        dhcp_end: "192.168.40.180",
        lease_time: "12h",
        upstream_bridge: "",
        members: [],
      });
    });
  });

  document.getElementById("btn-add-unit").addEventListener("click", () => {
    withDraft((draft) => {
      draft.vpn_units.push({
        id: nextID("unit", draft.vpn_units),
        name: "New Gateway",
        bridge_id: draft.bridges[0]?.id || "",
        profile_id: draft.vpn_profiles[0]?.id || "",
        container_name: nextID("vpn-gw", draft.vpn_units),
        upstream_bridge: "",
        max_clients: 128,
      });
    });
  });

  document.getElementById("btn-add-profile").addEventListener("click", () => {
    withDraft((draft) => {
      addVPNProfileDraft(draft);
    });
  });

  document.getElementById("btn-add-wifi").addEventListener("click", () => {
    withDraft((draft) => {
      draft.wifi_networks.push({
        id: nextID("wifi", draft.wifi_networks),
        name: "New Wi-Fi",
        ssid: "GeoBox-WiFi",
        bridge_id: draft.bridges[0]?.id || "",
        adapter: "",
        band: "5g",
        channel: 36,
        channel_width: 80,
        mode: "ac",
        security: "wpa2",
        password: "",
        hidden: false,
        wps_mode: "disabled",
      });
    });
  });

  document.getElementById("btn-add-fingerprint-profile").addEventListener("click", () => {
    withDraft((draft) => {
      draft.fingerprint_profiles.push({
        id: nextID("fp", draft.fingerprint_profiles),
        preset: "custom",
        ttl: 64,
        window_size: 65535,
        df: true,
        ecn: false,
        options: [],
      });
    });
  });

  document.getElementById("btn-add-policy").addEventListener("click", () => {
    withDraft((draft) => {
      draft.fingerprint_policies.push({
        id: nextID("policy", draft.fingerprint_policies),
        name: "New Policy",
        mac_address: "AA:BB:CC:DD:EE:FF",
        bridge_id: draft.bridges[0]?.id || "",
        fingerprint_profile_id: draft.fingerprint_profiles[0]?.id || "",
      });
    });
  });
}

const testHooks = {
  state,
  getVPNProfileUIKey,
  primeVPNProfileUIKeys,
  syncSelectedVPNProfileID,
  toggleVPNProfileAdvanced,
  summarizeVPNProtection,
  createDefaultVPNProfile,
  addVPNProfileDraft,
  removeVPNProfileDraft,
  renderVPNProfileCard,
  renderVPNProfileEditor,
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = testHooks;
}

// Helper to get current data object
function getCurrentData() {
  return {
    config: state.draftConfig,
    runtime: state.dashboard,
  };
}

// Helper to refresh current screen after changes
function refreshCurrentScreen() {
  const data = getCurrentData();
  if (state.currentScreen === "home") {
    renderHomeGrid(data);
  } else {
    renderScreen(state.currentScreen, data);
  }
}

// Setup mobile button handlers
function setupMobileHandlers() {
  // Add VPN Unit button
  const btnAddVPNUnit = document.getElementById("btn-add-vpn-unit");
  if (btnAddVPNUnit) {
    btnAddVPNUnit.addEventListener("click", () => {
      withDraft((draft) => {
        draft.vpn_units.push({
          id: nextID("unit", draft.vpn_units),
          name: "New VPN Unit",
          bridge_id: draft.bridges[0]?.id || "",
          profile_id: draft.vpn_profiles[0]?.id || "",
          container_name: nextID("vpn-gw", draft.vpn_units),
          upstream_bridge: "",
          max_clients: 128,
        });
        showToast("VPN unit added");
        refreshCurrentScreen();
      });
    });
  }

  // Add WiFi button
  const btnAddWifi = document.getElementById("btn-add-wifi");
  if (btnAddWifi) {
    btnAddWifi.addEventListener("click", () => {
      withDraft((draft) => {
        draft.wifi_networks.push({
          id: nextID("wifi", draft.wifi_networks),
          name: "New Wi-Fi",
          ssid: "GeoBox-WiFi",
          bridge_id: draft.bridges[0]?.id || "",
          adapter: "",
          band: "5g",
          channel: 36,
          channel_width: 80,
          mode: "ac",
          security: "wpa2",
          password: "",
          hidden: false,
          wps_mode: "disabled",
        });
        showToast("Wi-Fi network added");
        refreshCurrentScreen();
      });
    });
  }

  // Add Bridge button
  const btnAddBridge = document.getElementById("btn-add-bridge");
  if (btnAddBridge) {
    btnAddBridge.addEventListener("click", () => {
      withDraft((draft) => {
        draft.bridges.push({
          id: nextID("br", draft.bridges),
          name: "New Bridge",
          subnet: "192.168.40.0/24",
          gateway: "192.168.40.1",
          dhcp_start: "192.168.40.50",
          dhcp_end: "192.168.40.180",
          lease_time: "12h",
          upstream_bridge: "",
          members: [],
        });
        showToast("Bridge added");
        refreshCurrentScreen();
      });
    });
  }
}

// Initialize mobile-first UI
async function initNewUI() {
  // Setup navigation first
  setupNavigation();

  // Fetch initial data
  try {
    const dashboard = await fetchJson("/api/dashboard");
    state.dashboard = normalizeRuntimeState(dashboard.runtime || {});
    state.draftConfig = normalizeConfig(dashboard.config || {});

    // Render home grid
    renderHomeGrid({
      config: state.draftConfig,
      runtime: state.dashboard,
    });

    // Setup mobile button handlers
    setupMobileHandlers();

    // Setup WebSocket for updates
    setupWebSocket();
  } catch (err) {
    showToast("Failed to load data: " + err.message, "error");
  }
}

if (typeof window !== "undefined") {
  window.__vpnAppTestHooks = testHooks;
  window.ui = ui;
  hydrate()
    .then(() => {
      attachHandlers();
    })
    .catch(handleError);

  // Initialize on DOM ready (mobile-first UI)
  if (isBrowser) {
    document.addEventListener("DOMContentLoaded", initNewUI);
  }
}
