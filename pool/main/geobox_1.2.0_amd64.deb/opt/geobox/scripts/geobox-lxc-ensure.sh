#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "usage: geobox-lxc-ensure.sh <unit-id>"
  exit 1
fi

UNIT_ID="$1"
UNIT_ROOT="${GEOBOX_UNIT_ROOT:-/etc/geobox/units}"
UNIT_DIR="${UNIT_ROOT}/${UNIT_ID}"
source "${UNIT_DIR}/env"
BASE_DIR="${GEOBOX_LXC_BASE_DIR:-/var/lib/geobox/lxc}"
CONFIG_ROOT="${GEOBOX_LXC_CONFIG_ROOT:-/etc/geobox/lxc}"
SCRIPTS_DIR="${GEOBOX_SCRIPTS_DIR:-/opt/geobox/scripts}"
WAIT_RETRIES="${GEOBOX_LXC_WAIT_RETRIES:-30}"
WAIT_SLEEP="${GEOBOX_LXC_WAIT_SLEEP:-1}"
CONTAINER_DIR="${BASE_DIR}/${CONTAINER_NAME}"
CONFIG_TEMPLATE="${CONFIG_ROOT}/${UNIT_ID}.conf"
CONFIG_FILE="${CONTAINER_DIR}/config"
BOOTSTRAP_MARKER="${CONTAINER_DIR}/.geobox_bootstrapped"
BOOTSTRAP_BIN=""

container_state() {
  local output
  if ! output="$(lxc-info -n "${CONTAINER_NAME}" -P "${BASE_DIR}" -sH 2>/dev/null)"; then
    return 1
  fi
  output="$(tr -d '\r' <<<"${output}")"
  awk '{print toupper($1)}' <<<"${output}"
}
container_exists() {
  lxc-info -n "${CONTAINER_NAME}" -P "${BASE_DIR}" >/dev/null 2>&1 || [[ -d "${CONTAINER_DIR}" ]]
}
wait_for_container_state() {
  local desired="${1}"
  local attempts="${2:-${WAIT_RETRIES}}"
  local current=""
  local last_state=""
  for _ in $(seq 1 "${attempts}"); do
    if current="$(container_state)"; then
      last_state="${current}"
    else
      current=""
    fi
    if [[ "${current}" == "${desired}" ]]; then
      return 0
    fi
    if [[ "${desired}" == "STOPPED" && -z "${current}" ]]; then
      return 0
    fi
    sleep "${WAIT_SLEEP}"
  done
  [[ "${desired}" == "STOPPED" && -z "${last_state}" ]]
}
ensure_container_stopped() {
  case "$(container_state || true)" in
    RUNNING|STARTING|ABORTING|FAILED)
      lxc-stop -k -n "${CONTAINER_NAME}" -P "${BASE_DIR}" || true
      wait_for_container_state STOPPED "${WAIT_RETRIES}" || true
      ;;
  esac
}
ensure_container_running() {
  case "$(container_state || true)" in
    RUNNING)
      return 0
      ;;
    STARTING)
      wait_for_container_state RUNNING "${WAIT_RETRIES}"
      return $?
      ;;
    ABORTING|FAILED)
      ensure_container_stopped
      ;;
  esac
  lxc-start -n "${CONTAINER_NAME}" -P "${BASE_DIR}" -d
  wait_for_container_state RUNNING "${WAIT_RETRIES}"
}

mkdir -p "${BASE_DIR}"
if container_exists && [[ ! -d "${CONTAINER_DIR}/rootfs" ]]; then
  ensure_container_stopped
  lxc-destroy -n "${CONTAINER_NAME}" -P "${BASE_DIR}" || true
  rm -rf "${CONTAINER_DIR}"
fi

if ! container_exists; then
  if ! output="$(lxc-create -n "${CONTAINER_NAME}" -P "${BASE_DIR}" -t download -- -d debian -r trixie -a arm64 2>&1)"; then
    if ! grep -qi 'container already exists' <<<"${output}"; then
      echo "${output}"
      exit 1
    fi
  fi
fi

install -D -m 0644 "${CONFIG_TEMPLATE}" "${CONFIG_FILE}"

if [[ ! -f "${CONFIG_FILE}" ]]; then
  echo "missing LXC config: ${CONFIG_FILE}"
  exit 1
fi

case "${VPN_PROTOCOL}" in
  vless|hysteria2) BOOTSTRAP_BIN="sing-box" ;;
  wireguard) BOOTSTRAP_BIN="wg-quick" ;;
  openvpn) BOOTSTRAP_BIN="openvpn" ;;
  ikev2) BOOTSTRAP_BIN="ipsec" ;;
  l2tp_ipsec) BOOTSTRAP_BIN="xl2tpd" ;;
  sstp) BOOTSTRAP_BIN="sstpc" ;;
  zerotier) BOOTSTRAP_BIN="zerotier-one" ;;
esac

needs_bootstrap=0
if [[ ! -f "${BOOTSTRAP_MARKER}" ]]; then
  needs_bootstrap=1
elif [[ -n "${BOOTSTRAP_BIN}" ]]; then
  case "$(container_state || true)" in
    RUNNING|STARTING)
      ensure_container_running
      if ! lxc-attach -n "${CONTAINER_NAME}" -P "${BASE_DIR}" -- bash -lc "command -v ${BOOTSTRAP_BIN}" >/dev/null 2>&1; then
        needs_bootstrap=1
      fi
      ;;
    ABORTING|FAILED)
      ensure_container_stopped
      ;;
  esac
fi

if [[ "${needs_bootstrap}" -eq 1 ]]; then
  ensure_container_running
  lxc-attach -n "${CONTAINER_NAME}" -P "${BASE_DIR}" -- bash -lc "apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends $(${SCRIPTS_DIR}/geobox-container-packages.sh \"${VPN_PROTOCOL}\")"
  if [[ -n "${BOOTSTRAP_BIN}" ]]; then
    lxc-attach -n "${CONTAINER_NAME}" -P "${BASE_DIR}" -- bash -lc "command -v ${BOOTSTRAP_BIN}" >/dev/null 2>&1
  fi
  touch "${BOOTSTRAP_MARKER}"
  ensure_container_stopped
fi
