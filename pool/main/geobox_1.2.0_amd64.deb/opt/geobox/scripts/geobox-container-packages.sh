#!/usr/bin/env bash
set -euo pipefail
proto="${1:-}"
base_packages='ca-certificates iproute2 iputils-ping curl bash isc-dhcp-client nftables procps'
case "${proto}" in
  vless|hysteria2) echo "${base_packages}" ;;
  wireguard) echo "${base_packages} wireguard-tools" ;;
  openvpn) echo "${base_packages} openvpn" ;;
  ikev2) echo "${base_packages} strongswan" ;;
  l2tp_ipsec) echo "${base_packages} strongswan xl2tpd" ;;
  sstp) echo "${base_packages} sstp-client" ;;
  zerotier) echo "${base_packages} zerotier-one" ;;
  *) echo "${base_packages}" ;;
esac
