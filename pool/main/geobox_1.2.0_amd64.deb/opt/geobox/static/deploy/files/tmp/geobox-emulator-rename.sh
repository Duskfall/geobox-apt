#!/bin/bash
sleep 1
idx=0
for w in $(ls -1 /sys/class/net/ | grep '^wlan' | sort -V | tail -n 18); do
  ip link set "$w" down 2>/dev/null || true
  ip link set "$w" name "sim$idx" 2>/dev/null || true
  idx=$((idx+1))
done
